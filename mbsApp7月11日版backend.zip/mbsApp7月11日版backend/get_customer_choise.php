<?php

include 'db.php';

include 'store_choise.php';


?>
